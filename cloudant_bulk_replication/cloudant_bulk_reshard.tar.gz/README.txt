1.  Open BulkReplicationDriver.py and edit the edittable fields based on the instructions in the file.
2.  Run the utility by:  $ python BulkReplicationDriver.py
